import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ReminderDAO extends SQLiteOpenHelper {
    private static String database = "reminder";
    private static int versao = 1;

    public ReminderDAO(Context c) {
        super(c, database, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table reminder("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " lembrete TEXT, "
                + " descricao TEXT); ";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
        String sql = "drop table if exists reminder";
        db.execSQL(sql);
        this.onCreate(db);

    }
    public void salvar(Reminder r) {
        ContentValues v = new ContentValues();
        v.put("lembrete", r.getLembrete());
        v.put("descricao", r.getLembrete());
        getWritableDatabase().insert("reminder", null, v);
    }
    public List<Reminder> listaTarefas() {
        List<Reminder> Reminder = new ArrayList<Reminder>();
        String query = "SELECT * FROM reminder";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(query, null);
        if (c.moveToFirst()) {
            do {
                Reminder r = new Reminder();
                r.setId(Integer.parseInt(c.getString(0)));
                r.setLembrete(c.getString(1));
                r.setDescricao(c.getString(2));
                Reminder.add(r);
            } while (c.moveToNext());
        }
        return Reminder;
    }

}
