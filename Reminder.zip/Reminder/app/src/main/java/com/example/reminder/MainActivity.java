package com.example.reminder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.hardware.input.InputManager;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethod;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    ListView lista;
    ArrayAdapter<String> adapter;
    ArrayList<String> arrayList;
    ReminderDAO db = new ReminderDAO(this);
    String id;
    Bundle b = new Bundle();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        createNotificationChannel();
        NotificationManager nm= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.cancel(R.drawable.ic_launcher_foreground);
        //tela editar
        final CardView cardvieweditarid = (CardView) findViewById(R.id.cardvieweditarid);
        final CardView cardvieweditarlembrete = (CardView) findViewById(R.id.cardvieweditarlembrete);
        final CardView cardvieweditardescricao = (CardView) findViewById(R.id.cardvieweditardescricao);
        final EditText editarid = (EditText) findViewById(R.id.editarid);
        final EditText editarlembrete = (EditText) findViewById(R.id.editarlembrete);
        final EditText editardescricao = (EditText) findViewById(R.id.editardescricao);
        //ir para editar
        final Button irparaeditar = (Button)findViewById(R.id.editar);
        //no editar
        final Button voltaredit = (Button)findViewById(R.id.voltaredit);
        final Button salvaredit = (Button)findViewById(R.id.salvaredit);
        final Button cancelaredit = (Button)findViewById(R.id.cancelaredit);
        final Button excluiredit = (Button)findViewById(R.id.excluiredit);
        final TextView selecionelemb = (TextView) findViewById(R.id.selecionelembrete);
        final TextView txtedit = (TextView) findViewById(R.id.txteditarlembretes);
        //tela adicionar novo
        final TextView addlembrete = (TextView) findViewById(R.id.addlembrete);
        final CardView cardviewadicionarlembrete = (CardView) findViewById(R.id.cardviewadicionarlembrete);
        final CardView cardviewadicionardescricao = (CardView) findViewById(R.id.cardviewadicionardescricao);
        final EditText adicionarlembrete = (EditText) findViewById(R.id.adicionarlembrete);
        final EditText adicionardescricao = (EditText) findViewById(R.id.adicionardescricao);
        final Button irparaadicionarnovo = (Button)findViewById(R.id.adicionar);
        final Button salvarnovo = (Button)findViewById(R.id.salvarnovo);
        final Button cancelarnovo = (Button)findViewById(R.id.cancelarnovo);
        final Button voltarnovo = (Button)findViewById(R.id.voltarnovo);
        final Button timernotif =  (Button)findViewById(R.id.timerbotao);
        final Button timer10min = (Button)findViewById(R.id.timerbotao10min);
        final Button umasemana = (Button)findViewById(R.id.timerbotao1sem);
        //tela main
        lista = (ListView) findViewById(R.id.listView1);
        final TextView todoslembretes = (TextView)findViewById(R.id.todoslembretes);
        listarLembretesmain();
        //novodesab.
        cardviewadicionardescricao.setVisibility(View.GONE);
        cardviewadicionarlembrete.setVisibility(View.GONE);
        salvarnovo.setVisibility(View.GONE);
        cancelarnovo.setVisibility(View.GONE);
        addlembrete.setVisibility(View.GONE);
        txtedit.setVisibility(View.GONE);
        voltarnovo.setVisibility(View.GONE);
        timernotif.setVisibility(View.GONE);
        timer10min.setVisibility(View.GONE);
        umasemana.setVisibility(View.GONE);
        //editardesab.
        cardvieweditarid.setVisibility(View.GONE);
        cardvieweditardescricao.setVisibility(View.GONE);
        cardviewadicionarlembrete.setVisibility(View.GONE);
        salvaredit.setVisibility(View.GONE);
        cancelaredit.setVisibility(View.GONE);
        excluiredit.setVisibility(View.GONE);
        cardvieweditarlembrete.setVisibility(View.GONE);
        selecionelemb.setVisibility(View.GONE);
        voltaredit.setVisibility(View.GONE);
umasemana.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Toast.makeText(MainActivity.this, "A notificação de "+adicionarlembrete.getText()+" será enviada em 1 sem.", Toast.LENGTH_SHORT).show();
        //uma semana
        try {
            esconderTeclado();
            Intent intent = new Intent(MainActivity.this, ReminderBroadcast.class);
            intent.putExtra("Lembrete", adicionarlembrete.getText().toString());
            intent.putExtra("Descricao", adicionardescricao.getText().toString());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            long timeAtButtonClick = System.currentTimeMillis();
            long tenSecondsInMillis = (long) (1000 * 604.800);
            alarmManager.set(AlarmManager.RTC_WAKEUP,
                    timeAtButtonClick + tenSecondsInMillis,
                    pendingIntent);
        }catch (Exception e) {
            Toast.makeText(MainActivity.this, "Falha ao enviar notificação de "+ adicionarlembrete.getText(),
                            Toast.LENGTH_SHORT)
                    .show();
        }
    }
});
    timer10min.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(MainActivity.this, "A notificação de "+adicionarlembrete.getText()+" será enviada em 10 min.", Toast.LENGTH_SHORT).show();
            //dez minutos
            try {
            esconderTeclado();
            Intent intent = new Intent(MainActivity.this, ReminderBroadcast.class);
            intent.putExtra("Lembrete", adicionarlembrete.getText().toString());
            intent.putExtra("Descricao", adicionardescricao.getText().toString());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            long timeAtButtonClick = System.currentTimeMillis();
            long tenSecondsInMillis = 1000 * 60;
            alarmManager.set(AlarmManager.RTC_WAKEUP,
                    timeAtButtonClick + tenSecondsInMillis,
                    pendingIntent);
        }catch (Exception e) {
            Toast.makeText(MainActivity.this, "Falha ao enviar notificação de "+ adicionarlembrete.getText(),
                            Toast.LENGTH_SHORT)
                    .show();
        }
    }
});
        timernotif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                esconderTeclado();
                Toast.makeText(MainActivity.this, "A notificação de "+adicionarlembrete.getText()+" será enviada em 10 seg.", Toast.LENGTH_SHORT).show();
                //dez segundos
            try {
                Intent intent = new Intent(MainActivity.this, ReminderBroadcast.class);
                intent.putExtra("Lembrete", adicionarlembrete.getText().toString());
                intent.putExtra("Descricao", adicionardescricao.getText().toString());
                PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                long timeAtButtonClick = System.currentTimeMillis();
                long tenSecondsInMillis = 1000 * 10;
                alarmManager.set(AlarmManager.RTC_WAKEUP,
                        timeAtButtonClick + tenSecondsInMillis,
                        pendingIntent);
            }catch (Exception e) {
                Toast.makeText(MainActivity.this, "Falha ao enviar notificação de "+ adicionarlembrete.getText(),
                                Toast.LENGTH_SHORT)
                        .show();
            }
                        }
        });
//ir para adicionar novo
irparaadicionarnovo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        cardviewadicionardescricao.setVisibility(View.VISIBLE);
        cardviewadicionarlembrete.setVisibility(View.VISIBLE);
        salvarnovo.setVisibility(View.VISIBLE);
        cancelarnovo.setVisibility(View.GONE);
        irparaadicionarnovo.setVisibility(View.GONE);
        irparaeditar.setVisibility(View.GONE);
        adicionardescricao.setText(null);
        adicionarlembrete.setText(null);
        addlembrete.setVisibility(View.VISIBLE);
        todoslembretes.setVisibility(View.GONE);
        voltarnovo.setVisibility(View.VISIBLE);
        Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
        voltarnovo.startAnimation(slidedown);
        addlembrete.startAnimation(slidedown);
        salvarnovo.startAnimation(slidedown);
        cardviewadicionarlembrete.startAnimation(slidedown);
        cardviewadicionardescricao.startAnimation(slidedown);
        Animation slideup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
        cancelarnovo.startAnimation(slideup);
        irparaadicionarnovo.startAnimation(slideup);
        irparaeditar.startAnimation(slideup);
        todoslembretes.startAnimation(slideup);
        Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        lista.setAnimation(fadein);
    }
});
voltarnovo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        cardviewadicionardescricao.setVisibility(View.GONE);
        cardviewadicionarlembrete.setVisibility(View.GONE);
        salvarnovo.setVisibility(View.GONE);
        cancelarnovo.setVisibility(View.GONE);
        voltarnovo.setVisibility(View.GONE);
        irparaadicionarnovo.setVisibility(View.VISIBLE);
        irparaeditar.setVisibility(View.VISIBLE);
        adicionardescricao.setText(null);
        adicionarlembrete.setText(null);
        addlembrete.setVisibility(View.GONE);
        todoslembretes.setVisibility(View.VISIBLE);
        timernotif.setVisibility(View.GONE);
        timer10min.setVisibility(View.GONE);
        umasemana.setVisibility(View.GONE);
        Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
        irparaadicionarnovo.setAnimation(slidedown);
        irparaeditar.setAnimation(slidedown);
        todoslembretes.setAnimation(slidedown);
        Animation slideup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
        cardviewadicionardescricao.setAnimation(slideup);
        cardviewadicionarlembrete.setAnimation(slideup);
        salvarnovo.setAnimation(slideup);
        cancelarnovo.setAnimation(slideup);
        voltarnovo.setAnimation(slideup);
        addlembrete.setAnimation(slideup);
        Animation fadeout = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
        timernotif.setAnimation(fadeout);
        timer10min.setAnimation(fadeout);
        umasemana.setAnimation(fadeout);
        Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        lista.setAnimation(fadein);
    }
});
cancelarnovo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        cardviewadicionardescricao.setVisibility(View.GONE);
        cardviewadicionarlembrete.setVisibility(View.GONE);
        salvarnovo.setVisibility(View.GONE);
        cancelarnovo.setVisibility(View.GONE);
        irparaadicionarnovo.setVisibility(View.VISIBLE);
        irparaeditar.setVisibility(View.VISIBLE);
        adicionardescricao.setText(null);
        adicionarlembrete.setText(null);
        addlembrete.setVisibility(View.GONE);
        todoslembretes.setVisibility(View.VISIBLE);
        voltarnovo.setVisibility(View.GONE);
    }
});
        salvarnovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(adicionarlembrete.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Adicione um nome para seu lembrete", Toast.LENGTH_SHORT).show();
                }else {
                    if (adicionardescricao.getText().toString().isEmpty()) {
                        Toast.makeText(MainActivity.this, "Adicione uma descrição para seu lembrete", Toast.LENGTH_SHORT).show();
                    }else{
                        esconderTeclado();
                        Reminder r = new Reminder();
                        r.setLembrete(adicionarlembrete.getText().toString());
                        r.setDescricao(adicionardescricao.getText().toString());
                        db = new ReminderDAO(MainActivity.this);
                        db.salvar(r);
                        Toast.makeText(MainActivity.this, "Salvo", Toast.LENGTH_SHORT).show();
                        listarLembretesmain();
                        Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                        timernotif.setVisibility(View.VISIBLE);
                        timer10min.setVisibility(View.VISIBLE);
                        umasemana.setVisibility(View.VISIBLE);
                       lista.setAnimation(fadein);
                        Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
                        timernotif.setAnimation(slidedown);
                        timer10min.setAnimation(slidedown);
                        umasemana.setAnimation(slidedown);
                    }

                }

            }
        });
//ir para editar
irparaeditar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        txtedit.setVisibility(View.VISIBLE);
        cancelaredit.setVisibility(View.GONE);
        salvaredit.setVisibility(View.GONE);
        excluiredit.setVisibility(View.GONE);
        irparaadicionarnovo.setVisibility(View.GONE);
        irparaeditar.setVisibility(View.GONE);
        addlembrete.setVisibility(View.GONE);
        todoslembretes.setVisibility(View.GONE);
        selecionelemb.setVisibility(View.VISIBLE);
        voltaredit.setVisibility(View.VISIBLE);
        listarLembretesedit();
        Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
        selecionelemb.setAnimation(slidedown);
        txtedit.setAnimation(slidedown);
        voltaredit.setAnimation(slidedown);
        Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        lista.setAnimation(fadein);
    }
});
voltaredit.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        cardvieweditarid.setVisibility(View.GONE);
        cardvieweditardescricao.setVisibility(View.GONE);
        cardviewadicionarlembrete.setVisibility(View.GONE);
        salvaredit.setVisibility(View.GONE);
        cancelaredit.setVisibility(View.GONE);
        excluiredit.setVisibility(View.GONE);
        cardvieweditarlembrete.setVisibility(View.GONE);
        selecionelemb.setVisibility(View.GONE);
        irparaadicionarnovo.setVisibility(View.VISIBLE);
        irparaeditar.setVisibility(View.VISIBLE);
        txtedit.setVisibility(View.GONE);
        todoslembretes.setVisibility(View.VISIBLE);
        voltaredit.setVisibility(View.GONE);
        listarLembretesmain();
        Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
        irparaadicionarnovo.setAnimation(slidedown);
        irparaeditar.setAnimation(slidedown);
        todoslembretes.setAnimation(slidedown);
        Animation slideup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
       selecionelemb.setAnimation(slideup);
       txtedit.setAnimation(slideup);
       excluiredit.setAnimation(slideup);
       salvaredit.setAnimation(slideup);
        voltaredit.setAnimation(slideup);
        Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        lista.setAnimation(fadein);
    }
});
        //editar-salvar
        salvaredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Reminder r = new Reminder();
                r.setId(Integer.parseInt(id));
                r.setLembrete(editarlembrete.getText().toString());
                r.setDescricao(editardescricao.getText().toString());
                db = new ReminderDAO(MainActivity.this);
                db.editar(r);
                listarLembretesedit();
                editardescricao.setText(null);
                editarlembrete.setText(null);
                editarid.setText(null);
                esconderTeclado();
                Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                lista.setAnimation(fadein);
            }
        });
//excluir edicao
        excluiredit.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
                Animation slideup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
                editardescricao.setAnimation(slideup);
                editarlembrete.setAnimation(slideup);
                Reminder r = new Reminder();
                r.setId(Integer.parseInt(id));
                db = new ReminderDAO(MainActivity.this);
                db.excluir(r);
                listarLembretesedit();
                Toast.makeText(MainActivity.this, "Excluido", Toast.LENGTH_SHORT).show();
                editardescricao.setText(null);
                editarlembrete.setText(null);
                editarid.setText(null);
                editardescricao.setVisibility(View.GONE);
                editarlembrete.setVisibility(View.GONE);
                txtedit.setVisibility(View.VISIBLE);
                Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                txtedit.setAnimation(fadein);
              lista.setAnimation(fadein);
            }
        });
//clicar e retornar os valores para os campos
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Animation fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                Animation fadeout = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation slideup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
                Animation slidedown = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_down);
                txtedit.setVisibility(View.VISIBLE);
                cancelaredit.setVisibility(View.GONE);
                salvaredit.setVisibility(View.GONE);
                excluiredit.setVisibility(View.GONE);
                irparaadicionarnovo.setVisibility(View.GONE);
                irparaeditar.setVisibility(View.GONE);
                addlembrete.setVisibility(View.GONE);
                todoslembretes.setVisibility(View.GONE);
                voltaredit.setVisibility(View.VISIBLE);
                irparaadicionarnovo.setAnimation(fadeout);
                irparaeditar.setAnimation(fadeout);
                listarLembretesedit();
                    todoslembretes.setAnimation(slideup);
                    selecionelemb.setAnimation(slidedown);
                    txtedit.setAnimation(slidedown);
                    lista.setAnimation(fadein);
                    editardescricao.setVisibility(View.VISIBLE);
                    editarlembrete.setVisibility(View.VISIBLE);
                    editardescricao.setAnimation(slidedown);
                    editarlembrete.setAnimation(slidedown);
                    salvaredit.setVisibility(View.VISIBLE);
                    excluiredit.setVisibility(View.VISIBLE);
                    cardvieweditardescricao.setVisibility(View.VISIBLE);
                    cardvieweditarlembrete.setVisibility(View.VISIBLE);
                    selecionelemb.setVisibility(View.GONE);
                    try {
                        String conteudo = (String) lista.getItemAtPosition(i);
                        String palavra[] = conteudo.split(" - ");
                        id = palavra[0];
                    editarid.setText(palavra[0]);
                    editarlembrete.setText(palavra[1]);
                    editardescricao.setText(palavra[2]);
                    }catch(Exception e){
                    }
                }
        });
        cancelaredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cardvieweditarid.setVisibility(View.GONE);
                cardvieweditardescricao.setVisibility(View.GONE);
                cardviewadicionarlembrete.setVisibility(View.GONE);
                salvaredit.setVisibility(View.GONE);
                cancelaredit.setVisibility(View.GONE);
                excluiredit.setVisibility(View.GONE);
                cardvieweditarlembrete.setVisibility(View.GONE);
                selecionelemb.setVisibility(View.GONE);
                irparaadicionarnovo.setVisibility(View.VISIBLE);
                irparaeditar.setVisibility(View.VISIBLE);
                txtedit.setVisibility(View.GONE);
                todoslembretes.setVisibility(View.VISIBLE);
                voltaredit.setVisibility(View.GONE);
                listarLembretesmain();
            }
        });
    }
//fim oncreate
//métodos
//timer notificacao
    public void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "NotificationTimerA";
            String description = "Canal para timer de notificacao";
            int importance = NotificationManager.IMPORTANCE_MAX;
            NotificationChannel channel = new NotificationChannel("NotificacaoLembrete","NotificationTimerA", importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
// listar tela main
    public void listarLembretesmain(){
        List<Reminder> reminders = db.listaTarefas();
        arrayList = new ArrayList<String>();
        adapter = new
                ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,
                arrayList);
        lista.setAdapter(adapter);
        for (Reminder r : reminders) {
            arrayList.add(r.getLembrete() + " - "
                    + r.getDescricao());
            adapter.notifyDataSetChanged();
        }
    }
    //listar tela editar
    public void listarLembretesedit(){
        List<Reminder> reminders = db.listaTarefas();
        arrayList = new ArrayList<String>();
        adapter = new
                ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,
                arrayList);
        lista.setAdapter(adapter);
        for (Reminder r : reminders) {
            arrayList.add(r.getId() + " - " + r.getLembrete() + " - "
                    + r.getDescricao());
            adapter.notifyDataSetChanged();
        }
    }
  public void esconderTeclado(){
      View view = this.getCurrentFocus();
      if (view != null) {
          InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
          imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
      }
  }
}