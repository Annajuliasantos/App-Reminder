package com.example.reminder;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderBroadcast extends BroadcastReceiver {

    @Override

    public void onReceive(Context context, Intent intent) {



        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "NotificacaoLembrete")
                .setSmallIcon(R.drawable.icon)
                .setContentTitle(intent.getStringExtra("Lembrete"))
                .setContentText(intent.getStringExtra("Descricao"))
                .setPriority(NotificationCompat.PRIORITY_HIGH);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        StringBuilder sb = new StringBuilder();
        sb.append("Action: " + intent.getAction() + "\n");
        sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME).toString() + "\n");
        String log = sb.toString();
        Log.d(TAG, log);
        notificationManager.notify( 200, builder.build());

    }
}
