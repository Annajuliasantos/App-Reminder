public class Reminder {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLembrete() {
        return Lembrete;
    }

    public void setLembrete(String lembrete) {
        Lembrete = lembrete;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    private String Lembrete;
    private String descricao;
}
